import"./modulepreload-polyfill-B5Qt9EMX.js";const o={init(){$("#videoModal").on("hidden.bs.modal",function(){const i=$(this).find("iframe"),t=i.attr("src");i.attr("src",t)})}};o.init();
